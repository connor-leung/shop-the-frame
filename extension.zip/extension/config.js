const IS_DEV = false;
const BASE_URL = IS_DEV
  ? 'http://localhost:8000'
  : 'https://shop-the-frame-backend-60696442548.northamerica-northeast2.run.app';
const API_KEY = '7c98b8396ebfb09cd42c6c6c7b177929410f2a0989e0812ec0bf8bb2982738d2';
